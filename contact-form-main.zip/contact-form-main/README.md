# Envie E-mails de um Formulário de Contato HTML

Uma solução simples de envio de formulário usando apenas HTML. [Veja mais](https://www.youtube.com/watch?v=2umsItNQ9mI).
